

      
  <div id="readme" class="Box-body readme blob js-code-block-container p-5 p-xl-6 gist-border-0">
    <article class="markdown-body entry-content container-lg" itemprop="text"><table data-table-type="yaml-metadata">
  <thead>
  <tr>
  <th>title</th>
  <th>permalink</th>
  <th>menu</th>
  <th>layout</th>
  </tr>
  </thead>
  <tbody>
  <tr>
  <td><div>Questions - RGAA</div></td>
  <td><div>/publications/rgaa-accessibilite/questions/</div></td>
  <td><div><table>
  <thead>
  <tr>
  <th>title</th>
  <th>weight</th>
  </tr>
  </thead>
  <tbody>
  <tr>
  <td><div>Questions</div></td>
  <td><div>60</div></td>
  </tr>
  </tbody>
</table>
</div></td>
  <td><div>rgaa-accessibilite</div></td>
  </tr>
  </tbody>
</table>

<p>Vous pouvez poser vos questions sur la liste de discussion du RGAA accessible sur inscription.</p>
<div>
  <p>
    <a href="https://framalistes.org/sympa/subscribe/rgaa" rel="nofollow">S’inscrire à la liste de discussion RGAA</a>
  </p>
</div>
</article>
  </div>
