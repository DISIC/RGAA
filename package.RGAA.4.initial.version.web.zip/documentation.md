
      
  <div id="readme" class="Box-body readme blob js-code-block-container p-5 p-xl-6 gist-border-0">
    <article class="markdown-body entry-content container-lg" itemprop="text"><table data-table-type="yaml-metadata">
  <thead>
  <tr>
  <th>title</th>
  <th>permalink</th>
  <th>menu</th>
  <th>layout</th>
  </tr>
  </thead>
  <tbody>
  <tr>
  <td><div>Documentation - RGAA</div></td>
  <td><div>/publications/rgaa-accessibilite/documentation/</div></td>
  <td><div><table>
  <thead>
  <tr>
  <th>title</th>
  <th>weight</th>
  </tr>
  </thead>
  <tbody>
  <tr>
  <td><div>Documentation</div></td>
  <td><div>50</div></td>
  </tr>
  </tbody>
</table>
</div></td>
  <td><div>rgaa-accessibilite</div></td>
  </tr>
  </tbody>
</table>

<h3><a id="user-content-documentation" class="anchor" aria-hidden="true" href="#documentation"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.775 3.275a.75.75 0 001.06 1.06l1.25-1.25a2 2 0 112.83 2.83l-2.5 2.5a2 2 0 01-2.83 0 .75.75 0 00-1.06 1.06 3.5 3.5 0 004.95 0l2.5-2.5a3.5 3.5 0 00-4.95-4.95l-1.25 1.25zm-4.69 9.64a2 2 0 010-2.83l2.5-2.5a2 2 0 012.83 0 .75.75 0 001.06-1.06 3.5 3.5 0 00-4.95 0l-2.5 2.5a3.5 3.5 0 004.95 4.95l1.25-1.25a.75.75 0 00-1.06-1.06l-1.25 1.25a2 2 0 01-2.83 0z"></path></svg></a>Documentation</h3>
<p>Cette rubrique contiendra notamment :</p>
<ul>
<li>Un document de méthode pour apprendre à faire les tests du RGAA;</li>
<li>La liste des critères triple AAA des WCAG;</li>
<li>Un suivi des modifications entre les différentes versions du RGAA.</li>
</ul>
<p>Elle sera mise en ligne d’ici fin novembre 2019.</p>
</article>
  </div>
